package com.sip.fintech;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.log.LogAccessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
public class SipFintechApplication {

    private static final Logger log = LoggerFactory.getLogger(SipFintechApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(SipFintechApplication.class, args);
    }

    // This Bean runs once the application and its server are fully ready
    @Bean
    public ApplicationRunner logUrl() {
        return args -> {
            // Log the final URL clearly!
            log.info("\n=======================================================");
            log.info("🚀 DASHBOARD IS READY! Access the Frontend at:");
            log.info("👉 http://localhost:8080/");
            log.info("=======================================================");
        };
    }
}