package com.sip.fintech.controller;

import com.sip.fintech.model.SipResult;
import com.sip.fintech.service.CalculationService;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/planner") // New URL base for planner services
public class SipController {

    private final CalculationService calculationService;

    // Dependency Injection via constructor
    public SipController(CalculationService calculationService) {
        this.calculationService = calculationService;
    }

    // Endpoint to get the list of top 10 recommendations
    @GetMapping("/recommendations")
    public List<SipResult> getRecommendations(
            @RequestParam(defaultValue = "5000") BigDecimal monthlyInvestment,
            @RequestParam(defaultValue = "36") int durationMonths
    ) {
        // The service fetches, calculates, and sorts the results.
        return calculationService.getTopRecommendations(monthlyInvestment, durationMonths);
    }
}