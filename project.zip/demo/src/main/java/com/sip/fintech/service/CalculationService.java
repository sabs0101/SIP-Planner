package com.sip.fintech.service;

import com.sip.fintech.model.SipResult;
import com.sip.fintech.model.SipResult.PricePoint;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

// Imports for MF API JSON Parsing
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.io.IOException;

@Service
public class CalculationService {

    // --- Inject API Key and RestTemplate ---
    @Value("${api.alphavantage.key}")
    private String alphaVantageKey;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // --- FD and PPF Data (Local Map) ---
    private static final Map<String, Double> FIXED_ASSET_RATES = Map.of(
            "FD: Unity SFB", 0.0810,
            "FD: Ujjivan SFB", 0.0795,
            "FD: Axis Bank", 0.0710,
            "FD: HDFC Bank", 0.0695,
            "PPF: Government", 0.0710
    );

    // --- The list of top assets to recommend ---
    private static final List<String> TOP_ASSET_IDS = List.of(
            "STOCK: RELIANCE INDS (RELIANCE.BSE)",
            "STOCK: INFOSYS LTD (INFY.BSE)",
            "MF: Parag Parikh Flexi Cap Fund | 128628",
            "MF: Quant Small Cap Fund | 120828",
            "FD: Unity SFB",
            "FD: HDFC Bank",
            "PPF: Government"
    );

    // --- Core Recommendation Method ---
    public List<SipResult> getTopRecommendations(BigDecimal monthlyInvestment, int durationMonths) {
        List<SipResult> results = TOP_ASSET_IDS.stream()
                .map(assetId -> {
                    String assetType = assetId.split(":")[0].trim();
                    return calculateSip(assetId, assetType, monthlyInvestment, durationMonths);
                })
                .sorted(Comparator.comparingDouble((SipResult r) -> {
                    try {
                        return Double.parseDouble(r.getCagrReturnPercent().replace("%", ""));
                    } catch (Exception e) {
                        return Double.MIN_VALUE;
                    }
                }).reversed())
                .collect(Collectors.toList());

        return results;
    }

    // --- Core SIP Calculation Logic (Dispatcher) ---
    public SipResult calculateSip(String assetId, String assetType, BigDecimal monthlyInvestment, int durationMonths) {

        // --- CRITICAL FIX: Dispatch Fixed Assets FIRST (guaranteed path) ---
        if (assetType.equals("FD") || assetType.equals("PPF")) {
            Double rate = FIXED_ASSET_RATES.getOrDefault(assetId, 0.070);
            return calculateFixedReturn(assetId, assetType, monthlyInvestment, durationMonths, rate);
        }

        // --- MARKET-LINKED ASSETS (Stocks/MF) ---
        List<PricePoint> history = fetchHistoricalData(assetId, assetType, durationMonths);

        if (history.isEmpty() || history.size() < durationMonths) {
            return getErrorResult(assetId, assetType, "Not enough historical data for the duration.");
        }

        // --- Rupee Cost Averaging and Calculation (unchanged) ---
        BigDecimal totalInvested = BigDecimal.ZERO;
        BigDecimal totalUnits = BigDecimal.ZERO;

        for (int i = 0; i < durationMonths; i++) {
            PricePoint point = history.get(i);
            BigDecimal nav = point.getValue();
            BigDecimal unitsBought = monthlyInvestment.divide(nav, 5, RoundingMode.HALF_UP);
            totalUnits = totalUnits.add(unitsBought);
            totalInvested = totalInvested.add(monthlyInvestment);
        }

        BigDecimal latestNav = history.get(history.size() - 1).getValue();
        BigDecimal currentValue = totalUnits.multiply(latestNav).setScale(2, RoundingMode.HALF_UP);
        BigDecimal absoluteReturn = currentValue.subtract(totalInvested).setScale(2, RoundingMode.HALF_UP);

        double years = durationMonths / 12.0;
        double endValue = currentValue.doubleValue();
        double startValue = totalInvested.doubleValue();

        double cagr = 0.0;
        if (startValue > 0 && years > 0) {
            cagr = (Math.pow(endValue / startValue, 1.0 / years) - 1.0) * 100.0;
        }
        String cagrReturn = String.format("%.2f%%", cagr);

        SipResult result = new SipResult();
        result.setAssetName(assetId);
        result.setAssetType(assetType);
        result.setTotalInvested(totalInvested);
        result.setCurrentValue(currentValue);
        result.setAbsoluteReturn(absoluteReturn);
        result.setCagrReturnPercent(cagrReturn);
        result.setNavHistory(history);
        result.setAssetCode(getAssetCode(assetId, assetType));

        return result;
    }

    // --- Fixed Return Calculation (Guaranteed Rates) ---
    private SipResult calculateFixedReturn(String assetName, String assetType, BigDecimal monthlyInvestment, int durationMonths, double annualRate) {
        int numPeriods = durationMonths;
        double monthlyRate = annualRate / 12.0;

        // Final Value Calculation is done once to set the true final value
        double compoundFactor = Math.pow(1 + monthlyRate, numPeriods);
        double totalFutureValue = monthlyInvestment.doubleValue() * ((compoundFactor - 1) / monthlyRate) * (1 + monthlyRate);

        // Get the growth history (for the graph)
        List<PricePoint> growthHistory = getFixedAssetHybridSimulation(assetName, durationMonths, annualRate, monthlyInvestment.doubleValue());

        BigDecimal finalCurrentValue = new BigDecimal(totalFutureValue).setScale(2, RoundingMode.HALF_UP);
        BigDecimal finalTotalInvested = monthlyInvestment.multiply(new BigDecimal(numPeriods));
        BigDecimal absoluteReturn = finalCurrentValue.subtract(finalTotalInvested).setScale(2, RoundingMode.HALF_UP);

        SipResult result = new SipResult();
        result.setAssetName(assetName);
        result.setAssetType(assetType);
        result.setTotalInvested(finalTotalInvested);
        result.setCurrentValue(finalCurrentValue);
        result.setAbsoluteReturn(absoluteReturn);

        result.setCagrReturnPercent(String.format("%.2f%%", annualRate * 100));

        result.setNavHistory(growthHistory);
        result.setAssetCode(getAssetCode(assetName, assetType));

        return result;
    }


    // --- DATA FETCHING DISPATCHER (Only handles market-linked assets) ---
    private List<PricePoint> fetchHistoricalData(String assetId, String assetType, int durationMonths) {
        if (assetType.equals("STOCK")) {
            return fetchStockDataFromAlphaVantage(assetId, durationMonths);
        } else if (assetType.equals("MF")) {
            return fetchMutualFundData(assetId, durationMonths);
        } else {
            return Collections.emptyList(); // Should not be reached
        }
    }


    // ----------------------------------------------------
    // --- INTEGRATION & SIMULATION METHODS ---
    // ----------------------------------------------------

    // --- 1. Alpha Vantage Integration (STOCKS) ---
    private List<PricePoint> fetchStockDataFromAlphaVantage(String assetId, int months) {
        try {
            Matcher matcher = Pattern.compile("\\((.*?)\\)").matcher(assetId);
            String symbol = matcher.find() ? matcher.group(1) : "MSFT";

            String url = String.format(
                    "https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY_ADJUSTED&symbol=%s&apikey=%s",
                    symbol, alphaVantageKey);

            @SuppressWarnings("unchecked")
            Map<String, Object> response = restTemplate.getForObject(url, Map.class);

            if (response == null || response.containsKey("Error Message") || response.containsKey("Note")) {
                System.err.println("API Error or Limit Hit for " + symbol + ". Falling back to simulation.");
                return getStockFallbackSimulation(symbol, months);
            }

            @SuppressWarnings("unchecked")
            Map<String, Map<String, String>> monthlyData = (Map<String, Map<String, String>>) response.get("Monthly Adjusted Time Series");

            if (monthlyData == null || monthlyData.isEmpty()) {
                throw new Exception("Monthly Adjusted Time Series data not found in API response.");
            }

            List<PricePoint> history = new ArrayList<>();

            List<String> sortedDates = monthlyData.keySet().stream().sorted().collect(Collectors.toList());

            int startIndex = Math.max(0, sortedDates.size() - months);

            for (int i = startIndex; i < sortedDates.size(); i++) {
                String dateKey = sortedDates.get(i);
                String priceStr = monthlyData.get(dateKey).get("5. adjusted close");
                history.add(new PricePoint(dateKey, new BigDecimal(priceStr)));
            }

            System.out.println("✅ STOCK API SUCCESS: Fetched real data for " + symbol);
            return history;

        } catch (Exception e) {
            System.err.println("❌ STOCK API FAILURE: " + assetId + ". Cause: " + e.getMessage() + ". Using simulation.");
            return getStockFallbackSimulation(assetId, months);
        }
    }

    // --- 2. MFAPI.in Integration (MUTUAL FUNDS) ---
    private List<PricePoint> fetchMutualFundData(String assetId, int months) {
        try {
            String[] parts = assetId.split("\\|");
            if (parts.length < 2) {
                System.err.println("Invalid MF asset ID format. Falling back to simulation.");
                return getMFFallbackSimulation(assetId, months);
            }
            String schemeCode = parts[1].trim();

            String url = String.format("https://api.mfapi.in/mf/%s", schemeCode);
            String jsonResponse = restTemplate.getForObject(url, String.class);

            if (jsonResponse == null || jsonResponse.contains("Invalid scheme code")) {
                throw new IOException("MFAPI.in returned invalid scheme code or no data.");
            }

            Map<String, Object> fundData = objectMapper.readValue(jsonResponse, new TypeReference<Map<String, Object>>() {});

            @SuppressWarnings("unchecked")
            List<Map<String, String>> navHistoryRaw = (List<Map<String, String>>) fundData.get("data");

            if (navHistoryRaw == null || navHistoryRaw.isEmpty()) {
                throw new IOException("NAV history data list is empty.");
            }

            List<PricePoint> history = navHistoryRaw.stream()
                    .map(navEntry -> {
                        String dateStr = navEntry.get("date");
                        String[] dateParts = dateStr.split("-");
                        String isoDate = dateParts[2] + "-" + dateParts[1] + "-" + dateParts[0];

                        BigDecimal navValue = new BigDecimal(navEntry.get("nav"));

                        return new PricePoint(isoDate, navValue.setScale(4, RoundingMode.HALF_UP));
                    })
                    .sorted(Comparator.comparing(PricePoint::getDate))
                    .collect(Collectors.toList());

            int startIndex = Math.max(0, history.size() - months);

            System.out.println("✅ MF API SUCCESS: Fetched real data for Scheme " + schemeCode);
            return history.subList(startIndex, history.size());

        } catch (Exception e) {
            System.err.println("❌ MF API FAILURE: " + assetId + ". Cause: " + e.getMessage() + ". Using simulation.");
            return getMFFallbackSimulation(assetId, months);
        }
    }

    // --- FD/PPF HYBRID SIMULATION (Visual Realism) ---
    private List<PricePoint> getFixedAssetHybridSimulation(String assetId, int durationMonths, double annualRate, double monthlyInvestmentAmount) {
        int numPeriods = durationMonths;
        double monthlyRate = annualRate / 12.0;

        // Use asset ID hash code for a unique, consistent random seed per FD type
        long seed = (long) assetId.hashCode();
        Random uniqueRandom = new Random(seed);

        // The accumulator for the total value over time
        final double[] totalValueHolder = {0.0};

        List<PricePoint> growthHistory = IntStream.range(1, numPeriods + 1)
                .mapToObj(month -> {
                    // 1. Add the new monthly investment
                    totalValueHolder[0] += monthlyInvestmentAmount;

                    // 2. Calculate the interest on the *previous* total value for one month
                    double interest = totalValueHolder[0] * (monthlyRate);
                    totalValueHolder[0] += interest;

                    // 3. Add a Tiny, Unique Fluctuation (Visual Noise) for differentiation
                    double microVol = (uniqueRandom.nextDouble() * 0.005);
                    totalValueHolder[0] *= (1 + microVol);

                    return new PricePoint(
                            LocalDate.now().minusMonths(numPeriods - month).toString(),
                            BigDecimal.valueOf(totalValueHolder[0]).setScale(2, RoundingMode.HALF_UP)
                    );
                })
                .collect(Collectors.toList());

        return growthHistory;
    }


    // --- FALLBACK SIMULATIONS ---
    private List<PricePoint> getStockFallbackSimulation(String assetId, int months) {
        double baseNav = assetId.contains("RELIANCE") ? 250.00 : 100.00;
        double trend = 0.3;
        double volatility = 5.0;
        return generateSampleData(months, baseNav, trend, volatility);
    }

    private List<PricePoint> getMFFallbackSimulation(String assetId, int months) {
        double baseNav = 35.00;
        double trend = 0.4;
        double volatility = 3.0;
        return generateSampleData(months, baseNav, trend, volatility);
    }

    private List<PricePoint> generateSampleData(int months, double baseNav, double trend, double volatility) {
        LocalDate date = LocalDate.now();
        final BigDecimal[] currentNavHolder = {new BigDecimal(baseNav)};

        return IntStream.range(0, months)
                .mapToObj(i -> {
                    BigDecimal previousNav = currentNavHolder[0];
                    double fluctuation = (Math.random() * volatility) - (volatility / 2.0);
                    double monthlyChange = trend + fluctuation;

                    BigDecimal newNav = previousNav.add(BigDecimal.valueOf(monthlyChange)).setScale(2, RoundingMode.HALF_UP);
                    currentNavHolder[0] = newNav;

                    return new PricePoint(
                            LocalDate.now().minusMonths(months - 1 - i).toString(),
                            newNav
                    );
                })
                .collect(Collectors.toList());
    }

    // --- Code Extractor (unchanged) ---
    private String getAssetCode(String assetName, String assetType) {
        Random random = new Random();

        if (assetType.equals("STOCK")) {
            Matcher matcher = Pattern.compile("\\((.*?)\\)").matcher(assetName);
            if (matcher.find()) {
                String fullTicker = matcher.group(1);
                if (fullTicker.contains(".")) {
                    String exchange = fullTicker.substring(fullTicker.indexOf(".") + 1);
                    String ticker = fullTicker.substring(0, fullTicker.indexOf("."));
                    return exchange + ":" + ticker;
                }
                return "EXCH:" + fullTicker;
            }
            return "EXCH:TICKER";
        }

        if (assetType.equals("MF")) {
            String[] parts = assetName.split("\\|");
            if (parts.length > 1) {
                return "SCHEME:" + parts[1].trim();
            }
            return "ISIN:MFREF";
        }

        if (assetType.equals("FD")) {
            long ref = (long)(random.nextDouble() * 9000000000L) + 1000000000L;
            return "FD-REF-" + ref;
        }
        if (assetType.equals("PPF")) {
            return "PPF-GOV-IND";
        }
        return "N/A";
    }

    private SipResult getErrorResult(String id, String type, String message) {
        SipResult error = new SipResult();
        error.setAssetName(id);
        error.setAssetType(type);
        error.setCagrReturnPercent("ERROR: " + message);
        error.setNavHistory(Collections.emptyList());
        error.setTotalInvested(BigDecimal.ZERO);
        error.setCurrentValue(BigDecimal.ZERO);
        error.setAbsoluteReturn(BigDecimal.ZERO);
        return error;
    }
}