package com.sip.fintech.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

@Data
public class SipResult {
    private String assetName;
    private String assetType; // MF, Stock, FD, PPF
    private BigDecimal totalInvested;
    private BigDecimal currentValue;
    private BigDecimal absoluteReturn;
    private String cagrReturnPercent; // CAGR as a formatted String

    private String assetCode; // Ticker, ISIN, or Account Ref

    private List<PricePoint> navHistory; // For chart data

    // Inner class representing a single data point (date and price/NAV)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PricePoint {
        private String date;
        private BigDecimal value;
    }
}