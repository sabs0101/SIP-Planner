let navChartInstance = null;
let allRecommendations = [];

// --- CORE EVENT LISTENER ---
document.getElementById('recommendation-form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);

    // CRUCIAL: Robustly convert form data to URL parameters
    const params = new URLSearchParams({
        monthlyInvestment: formData.get('monthlyInvestment'),
        durationMonths: formData.get('durationMonths')
    }).toString();

    const loadingDiv = document.getElementById('loading');
    const recContainer = document.getElementById('recommendations-container');
    const resultsDiv = document.getElementById('results');

    // Hide everything and show loader
    resultsDiv.classList.add('hidden');
    recContainer.classList.add('hidden');
    loadingDiv.classList.remove('hidden');

    try {
        // 1. Call the Java Backend API
        const response = await fetch(`/api/planner/recommendations?${params}`);

        if (!response.ok) {
            console.error(`Network Error: Server responded with status ${response.status}`);
            throw new Error(`HTTP error! Status: ${response.status}. Check Java Console.`);
        }

        allRecommendations = await response.json();

        // 2. CRITICAL: Check for Java-side exceptions embedded in the response
        if (allRecommendations.length > 0 && allRecommendations[0].cagrReturnPercent.startsWith("ERROR")) {
            alert(`Backend Calculation Error: ${allRecommendations[0].cagrReturnPercent}`);
            return;
        }

        // 3. Render the 10 clickable cards
        renderRecommendationCards(allRecommendations);

        // 4. Show containers
        recContainer.classList.remove('hidden');
        if (allRecommendations.length > 0) {
            displayDetailedResult(allRecommendations[0]);
            resultsDiv.classList.remove('hidden');
        }

    } catch (error) {
        // This catch block prevents the application from getting 'stuck'
        console.error('CRITICAL FRONTEND/NETWORK ERROR:', error);
        alert(`Request Failed. Please check the browser console (F12) for network errors and ensure the Java server is running.`);
    } finally {
        // 5. Hide Loading Animation
        loadingDiv.classList.add('hidden');
    }
});


// --- HELPER FUNCTION TO GET ASSET CODE (Used by renderRecommendationCards) ---
function getAssetCodeForCard(assetName) {
    // This function is for aesthetic display on the card only
    const match = assetName.match(/\((.*?)\)/);
    if (match) {
        return match[1].trim();
    }
    const parts = assetName.split('|');
    if (parts.length > 1) {
        return parts[1].trim();
    }
    return assetName.split(':')[1] ? assetName.split(':')[1].trim() : 'N/A';
}

// --- CORE FUNCTION TO RENDER ALL 10 CARDS ---
function renderRecommendationCards(recommendations) {
    const container = document.getElementById('card-grid');
    container.innerHTML = ''; // Clear previous cards

    if (recommendations.length === 0) {
        container.innerHTML = '<p style="grid-column: span 4; text-align: center;">No recommendations found based on your criteria.</p>';
        return;
    }

    const topCagr = recommendations[0].cagrReturnPercent;

    recommendations.forEach((data, index) => {
        const card = document.createElement('div');

        const isBest = data.cagrReturnPercent === topCagr && data.assetType !== 'FD' && data.assetType !== 'PPF';

        card.className = 'recommendation-card' + (isBest ? ' best-option' : '');
        card.dataset.index = index;

        let displayAssetName = data.assetName.split(':')[1] ? data.assetName.split(':')[1].trim() : data.assetName;

        card.innerHTML = `
            <h3>${displayAssetName.substring(0, 18).trim()}...</h3>
            <p>Type: <strong>${data.assetType}</strong></p>
            <p>CAGR: <span class="card-cagr">${data.cagrReturnPercent}</span></p>
        `;

        card.addEventListener('click', () => displayDetailedResult(data));

        container.appendChild(card);
    });
}


// --- CORE FUNCTION TO DISPLAY DETAILED RESULTS AND CHART ---
function displayDetailedResult(data) {

    const formatCurrency = (value) => {
        const number = parseFloat(value);
        if (isNaN(number)) return '₹0.00';
        return `₹${number.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    };

    // --- Retrieve Duration for Graph Title ---
    const investmentDuration = document.getElementById('duration').value;
    const finalValue = formatCurrency(data.currentValue);

    // 1. Update Detailed Metrics
    document.getElementById('result-asset-name').textContent = `${data.assetName} [Code: ${data.assetCode}]`;

    document.getElementById('total-invested').textContent = formatCurrency(data.totalInvested);
    document.getElementById('current-value').textContent = formatCurrency(data.currentValue);

    // Apply conditional color based on gain/loss
    const absReturnEl = document.getElementById('absolute-return');
    const absoluteReturnValue = parseFloat(data.absoluteReturn);

    absReturnEl.textContent = formatCurrency(data.absoluteReturn);
    absReturnEl.classList.remove('highlight-gain', 'highlight-loss');

    if (absoluteReturnValue >= 0) {
        absReturnEl.classList.add('highlight-gain');
    } else {
        absReturnEl.classList.add('highlight-loss');
    }

    document.getElementById('cagr-return').textContent = data.cagrReturnPercent;

    // 2. Render Chart
    const chartContainer = document.querySelector('.chart-container');
    if (data.navHistory && data.navHistory.length > 0) {
        renderChart(data.navHistory, data.assetType, investmentDuration, finalValue);
        chartContainer.style.display = 'block';
    } else {
        if(navChartInstance) navChartInstance.destroy();
        chartContainer.style.display = 'none';
    }

    document.getElementById('results').classList.remove('hidden');
}


// --- FUNCTION TO RENDER CHART ---
function renderChart(history, assetType, investmentDuration, finalValue) {
    const ctx = document.getElementById('navChart').getContext('2d');

    const dates = history.map(item => item.date);
    const values = history.map(item => item.value);

    if (navChartInstance) {
        navChartInstance.destroy();
    }

    let graphLabel;
    let lineTension;
    const durationInYears = (investmentDuration / 12).toFixed(1);

    if (assetType === 'STOCK' || assetType === 'MF') {
        // Market-linked assets: Show volatility and past duration
        graphLabel = `Past ${durationInYears} Years History (API Data)`;
        lineTension = 0.15;
    } else {
        // Fixed income (FD/PPF): Show the final projected value
        graphLabel = `Projected Final Value: ${finalValue} (over ${durationInYears} Years)`;
        lineTension = 0.9;
    }


    navChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: graphLabel,
                data: values,
                borderColor: '#007bff',
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                borderWidth: 3,
                pointRadius: 0,
                tension: lineTension
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { display: true, title: { display: true, text: 'Date' } },
                y: { display: true, title: { display: true, text: 'Value (₹)' } }
            },
            plugins: {
                legend: { display: true }
            }
        }
    });
}